const { defineConfig } = require('@vue/cli-service')
module.exports = defineConfig({
  transpileDependencies: true,
  devServer: {
    host: '0.0.0.0', // 配置localhost会无法使用IP访问
    port: 8090,
    open: true
  }
})
