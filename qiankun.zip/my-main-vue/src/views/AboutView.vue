<template>
  <div class="about">
    <h1>父about</h1>
  </div>
</template>
