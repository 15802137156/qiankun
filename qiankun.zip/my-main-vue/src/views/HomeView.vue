<template>
  <div class="home">
    父main
    <div class="click" @click="handleClick">点击向子应用发送消息</div>
    {{ mesp.project_id }}
  </div>
</template>

<script>
import actions from '@/action'

export default {
  name: 'Home',
  data() {
    return {
      mesp: {
        project_id: '父平台数据'
      }
    }
  },
  mounted() {
    console.log(999999999, this.mesp)
    // 注册一个观察者函数
    actions.onGlobalStateChange((state, preState) => {
      console.log(preState, '主应用观察者变更前')
      console.log(state, '主应用观察者变更后')
      this.mesp = state
    })
  },
  methods: {
    handleClick() {
      actions.setGlobalState(this.mesp)
      // this.$router.push('/app-vue')
    },
  }
}
</script>
<style lang="scss" scoped>
.click {
  color: #f00;
  padding: 20px;
  font-size: 16px;
  cursor: pointer;
}
</style>