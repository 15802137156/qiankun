// 乾坤全局通信
import { initGlobalState } from 'qiankun'
const initState = {
    // 这里写初始化数据
}
const actions = initGlobalState(initState)
actions.onGlobalStateChange((state, preState) => {
    console.log(preState, '主应用变更前');
    console.log(state, '主应用变更后');

})
export default actions
