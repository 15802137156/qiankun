<template>
  <div id="app">
    <nav>
      <router-link to="/">Home</router-link> |
      <router-link to="/about">About</router-link>
    </nav>
    <div class="click" @click="handleClick">点我向父应用发送数据</div>
    <div class="click">{{ mesp.project_id }} - 接受父平台数据</div>
    <router-view />
  </div>
</template>

<script>
import actions from '@/action'

export default {
  name: 'Home',
  data() {
    return {
      mesp: {}
    }
  },
  mounted() {
    actions.onGlobalStateChange(state => {
      console.log(state, '子应用检测数据')
      this.mesp = state
    }, true) // onGlobalStateChange 第二个参数设置为true，会立即触发一次观察者函数
  },
  methods: {
    handleClick() {
      actions.setGlobalState({ project_id: '子平台数据' })
    }
  }
}
</script>

<style lang="scss" scoped>
#app {
  text-align: center;
  color: #2c3e50;
}

nav {
  padding: 30px;
}

nav a {
  font-weight: bold;
  color: #2c3e50;
}

nav a.router-link-exact-active {
  color: #42b983;
}
.click {
  color: #0f0;
  padding: 20px;
  font-size: 16px;
  cursor: pointer;
}
</style>
